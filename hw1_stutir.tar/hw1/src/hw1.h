#ifndef HW1
#define HW1
#include<stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

bool is_valid(char* modif);
void print_err();
bool is_findingword(char* modif);
int read_stats(char* modif, char* modif2 ,char * word);
int count_words(char * line);
//void write_to_STDERR(struct Stats e);
void upper(char* cap);
void lower(char* cap);
void title(char* cap);
void print_to_term(char* line);
int find_words(char *line , char * word);
void remove_char(char* line, char c);
void remv(char* line, char* word);

int call_modification(char* modif, char* line, char * word);

#endif 