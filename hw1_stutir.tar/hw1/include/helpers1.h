// Define all helper functions for hw1 in this file
